from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render

from App_agenda.models import Cita
from .models import Servicio


def catalogo_view(request):
	servicios = Servicio.objects.filter(activo=True).order_by('nombre')
	return render(request, 'App_servicios/catalogo.html', {'servicios': servicios})


def solicitudes_view(request):
	solicitudes = Cita.objects.filter(estado='pendiente').select_related(
		'cliente__persona', 'servicio'
	).order_by('fecha', 'hora')
	return render(request, 'App_agenda/solicitudes.html', {'solicitudes': solicitudes})


def actualizar_solicitud_view(request, cita_id, estado):
	if request.method == 'POST' and estado in ('confirmada', 'rechazada'):
		cita = get_object_or_404(Cita, pk=cita_id, estado='pendiente')
		cita.estado = estado
		cita.save(update_fields=['estado'])
		messages.success(request, f'La solicitud fue {estado}.')
	return redirect('solicitudes')


def gestionar_servicios_view(request):
	servicios = Servicio.objects.all().order_by('nombre')
	return render(request, 'App_servicios/gestionar_servicios.html', {'servicios': servicios})


def crear_servicio_view(request):
	if request.method == 'POST':
		Servicio.objects.create(
			nombre=request.POST.get('nombre', '').strip(),
			precio=request.POST.get('precio', 0),
			duracion_minutos=request.POST.get('duracion_minutos', 0),
			descripcion=request.POST.get('descripcion', '').strip(),
		)
		messages.success(request, 'El servicio fue creado correctamente.')
	return redirect('gestionar_servicios')


def editar_servicio_view(request, servicio_id):
	servicio = get_object_or_404(Servicio, pk=servicio_id)
	if request.method == 'POST':
		servicio.nombre = request.POST.get('nombre', '').strip()
		servicio.precio = request.POST.get('precio', servicio.precio)
		servicio.duracion_minutos = request.POST.get(
			'duracion_minutos', servicio.duracion_minutos
		)
		servicio.descripcion = request.POST.get('descripcion', '').strip()
		servicio.activo = 'activo' in request.POST
		servicio.save()
		messages.success(request, 'El servicio fue actualizado correctamente.')
	return redirect('gestionar_servicios')


def desactivar_servicio_view(request, servicio_id):
	servicio = get_object_or_404(Servicio, pk=servicio_id)
	if request.method == 'POST':
		servicio.activo = False
		servicio.save(update_fields=['activo'])
		messages.success(request, 'El servicio fue retirado del catalogo.')
	return redirect('gestionar_servicios')
