from django.db import models


class Servicio(models.Model):
	nombre = models.CharField(max_length=120)
	precio = models.DecimalField(max_digits=10, decimal_places=2)
	duracion_minutos = models.PositiveIntegerField()
	descripcion = models.TextField(blank=True)
	activo = models.BooleanField(default=True)

	def __str__(self):
		return self.nombre
