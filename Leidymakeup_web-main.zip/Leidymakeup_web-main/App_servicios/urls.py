from django.urls import path
from .views import (
    catalogo_view,
    crear_servicio_view,
    desactivar_servicio_view,
    editar_servicio_view,
    gestionar_servicios_view,
    solicitudes_view,
    actualizar_solicitud_view,
)


urlpatterns = [
    path('catalogo/', catalogo_view, name='catalogo'),
    path('solicitudes/', solicitudes_view, name='solicitudes'),
    path('solicitudes/<int:cita_id>/<str:estado>/', actualizar_solicitud_view, name='actualizar_solicitud'),
    path('gestionar/', gestionar_servicios_view, name='gestionar_servicios'),
    path('crear/', crear_servicio_view, name='crear_servicio'),
    path('editar/<int:servicio_id>/', editar_servicio_view, name='editar_servicio'),
    path('desactivar/<int:servicio_id>/', desactivar_servicio_view, name='desactivar_servicio'),
]