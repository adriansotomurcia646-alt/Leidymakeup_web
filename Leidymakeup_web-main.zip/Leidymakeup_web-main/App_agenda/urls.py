from django.urls import path
from . import views
from .views import reservar_cita_view, mis_citas_view, calendario_view


urlpatterns = [
    path('reservar/clientes/', reservar_cita_view, name='reservar_cita'),
    path('mis-citas/cliente/', mis_citas_view, name='mis_citas'),
    path('calendario/estilista/', calendario_view, name='calendario'),
]