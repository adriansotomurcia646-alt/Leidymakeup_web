from django.shortcuts import render

from App_servicios.models import Servicio
from .models import Cita


def reservar_cita_view(request):
	servicios = Servicio.objects.filter(activo=True).order_by('nombre')
	return render(request, 'App_agenda/reservar_cita.html', {'servicios': servicios})


def mis_citas_view(request):
	citas = Cita.objects.none()
	if request.user.is_authenticated and hasattr(request.user, 'cliente'):
		citas = Cita.objects.filter(cliente=request.user.cliente).select_related(
			'servicio', 'estilista__persona'
		).order_by('-fecha', '-hora')
	return render(request, 'App_agenda/mis_citas.html', {'citas': citas})


def calendario_view(request):
	citas = Cita.objects.filter(estado='confirmada').select_related(
		'cliente__persona', 'servicio', 'estilista__persona'
	).order_by('fecha', 'hora')
	if request.user.is_authenticated and hasattr(request.user, 'estilista'):
		citas = citas.filter(estilista=request.user.estilista)
	return render(request, 'App_agenda/calendario.html', {'citas': citas})
