from django.db import models
from App_usuarios.models import Cliente, Estilista
from App_servicios.models import Servicio


class Horario(models.Model):
	estilista = models.ForeignKey(Estilista, on_delete=models.CASCADE, related_name='horarios')
	dia_semana = models.PositiveSmallIntegerField(help_text='0 lunes, 6 domingo')
	hora_inicio = models.TimeField()
	hora_fin = models.TimeField()
	activo = models.BooleanField(default=True)

	def __str__(self):
		return f'{self.estilista} - día {self.dia_semana}'


class Cita(models.Model):
	ESTADOS = (
		('pendiente', 'Pendiente'),
		('confirmada', 'Confirmada'),
		('rechazada', 'Rechazada'),
		('cancelada', 'Cancelada'),
	)

	cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, related_name='citas')
	estilista = models.ForeignKey(Estilista, on_delete=models.CASCADE, related_name='citas')
	servicio = models.ForeignKey(Servicio, on_delete=models.PROTECT, related_name='citas')
	fecha = models.DateField()
	hora = models.TimeField()
	estado = models.CharField(max_length=20, choices=ESTADOS, default='pendiente')
	notas = models.TextField(blank=True)

	def __str__(self):
		return f'{self.servicio} - {self.fecha} {self.hora}'
