from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', RedirectView.as_view(url='/usuarios/login/', permanent=False), name='inicio'),
    path('usuarios/', include('App_usuarios.urls')),
    path('servicios/', include('App_servicios.urls')),
    path('agenda/', include('App_agenda.urls')),
    path('facturacion/', include('App_facturacion.urls')),
]