from django.shortcuts import render
from django.db.utils import OperationalError
import json

from .models import RegistroCobro


def inventario_view(request):
	try:
		registros = list(RegistroCobro.objects.select_related(
			'cliente__persona', 'cita__servicio'
		).order_by('-fecha'))
	except OperationalError:
		# La base puede no tener todavía las migraciones de la app.
		registros = []

	contexto = {
		'registros': registros,
		'total_clientes': len({registro.cliente_id for registro in registros}),
		'total_pendiente': sum((registro.saldo_pendiente for registro in registros), 0),
		'registros_json': json.dumps([
			{
				'cliente': str(registro.cliente),
				'servicio': registro.cita.servicio.nombre,
				'fecha': registro.fecha.isoformat(),
				'monto': float(registro.monto_total),
				'atendido': registro.saldo_pendiente == 0,
			}
			for registro in registros
		]),
	}
	return render(request, 'App_facturacion/inventario.html', contexto)
