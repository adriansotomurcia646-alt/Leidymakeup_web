from django.urls import path
from .views import login_view, perfil_view, registro_view

app_name = 'App_usuarios'


urlpatterns = [
    path('login/', login_view, name='login'),
    path('registro/', registro_view, name='registro'),
    path('perfil/', perfil_view, name='perfil'),
]