from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.shortcuts import redirect, render


def login_view(request):
	rol_seleccionado = request.POST.get('rol', request.GET.get('rol', 'cliente'))

	if request.method == 'POST':
		username = request.POST.get('username', '').strip()
		password = request.POST.get('password', '')
		usuario = authenticate(request, username=username, password=password)

		if usuario is None:
			messages.error(request, 'Credenciales incorrectas, por favor inténtelo nuevamente.')
		else:
			rol_valido = (
				rol_seleccionado == 'cliente' and usuario.es_cliente()
			) or (
				rol_seleccionado == 'estilista' and usuario.es_estilista()
			)

			if not rol_valido:
				mensaje = (
					'Esta cuenta no tiene permisos de estilista.'
					if rol_seleccionado == 'estilista'
					else 'Esta cuenta no tiene permisos de cliente.'
				)
				messages.error(request, mensaje)
			else:
				login(request, usuario)
				return redirect('calendario' if rol_seleccionado == 'estilista' else 'mis_citas')

	return render(
		request,
		'App_usuarios/login.html',
		{'rol_seleccionado': rol_seleccionado},
	)


def registro_view(request):
	# TODO: implementar el formulario de registro cuando se agregue su template.
	return redirect('App_usuarios:login')


def perfil_view(request):
	# TODO: implementar el perfil cuando se agregue su template.
	return redirect('App_usuarios:login')
